package com.phantom.recoilassistant.overlay

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.phantom.recoilassistant.data.PlayStyle
import com.phantom.recoilassistant.data.Recommender
import com.phantom.recoilassistant.data.SensProfile
import com.phantom.recoilassistant.data.Store
import com.phantom.recoilassistant.data.Weapon
import com.phantom.recoilassistant.data.Weapons
import com.phantom.recoilassistant.ui.Palette
import com.phantom.recoilassistant.ui.chip
import com.phantom.recoilassistant.ui.dp
import com.phantom.recoilassistant.ui.label
import com.phantom.recoilassistant.ui.lp
import com.phantom.recoilassistant.ui.rounded
import kotlin.math.abs

/**
 * Owns the floating bubble + compact panel. Uses only the standard overlay window
 * (TYPE_APPLICATION_OVERLAY). It never reads or touches the game, and sends no input.
 */
class OverlayController(
    private val ctx: Context,
    private val onClose: () -> Unit
) {
    private val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val store = Store(ctx)
    private val alphas = floatArrayOf(1f, 0.75f, 0.5f)
    private val tabNames = listOf("Weapon", "Sens", "Gyro", "Drill")
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    private var weaponIdx = store.weaponIdx.coerceIn(0, Weapons.all.lastIndex)
    private var style = PlayStyle.values()[store.styleOrd.coerceIn(0, PlayStyle.values().lastIndex)]
    private var alphaIdx = store.alphaIdx.coerceIn(0, alphas.lastIndex)
    private var tab = 0
    private var expanded = false

    private lateinit var tabRow: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout

    private val bubbleP = newParams(ctx.dp(44), ctx.dp(44))
    private val panelP = newParams(panelWidth(), WindowManager.LayoutParams.WRAP_CONTENT)
    private val bubble: View = buildBubble()
    private val panel: View = buildPanel()

    // ---------- lifecycle ----------

    fun show() {
        applyAlpha()
        render()
        wm.addView(bubble, bubbleP)
    }

    fun destroy() {
        runCatching { wm.removeView(bubble) }
        runCatching { wm.removeView(panel) }
    }

    /** Call when the screen rotates so the panel still fits. */
    fun refreshLayout() {
        panelP.width = panelWidth()
        scroll.layoutParams = LinearLayout.LayoutParams(MATCH, scrollHeight())
        val p = if (expanded) panelP else bubbleP
        val v = if (expanded) panel else bubble
        clamp(p, p.width, if (expanded) panel.height else p.height)
        runCatching { wm.updateViewLayout(v, p) }
    }

    // ---------- window helpers ----------

    private fun newParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
        PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.TOP or Gravity.START
        x = store.posX
        y = store.posY
    }

    private fun screenW() = ctx.resources.displayMetrics.widthPixels
    private fun screenH() = ctx.resources.displayMetrics.heightPixels
    private fun panelWidth() = minOf(ctx.dp(290), screenW() - ctx.dp(16))
    private fun scrollHeight() = minOf(ctx.dp(210), (screenH() * 0.5f).toInt())

    private fun clamp(p: WindowManager.LayoutParams, w: Int, h: Int) {
        p.x = p.x.coerceIn(0, maxOf(0, screenW() - w))
        p.y = p.y.coerceIn(0, maxOf(0, screenH() - h))
    }

    private fun setExpanded(v: Boolean) {
        if (v == expanded) return
        val from = if (expanded) panel else bubble
        val fp = if (expanded) panelP else bubbleP
        val to = if (v) panel else bubble
        val tp = if (v) panelP else bubbleP
        tp.x = fp.x
        tp.y = fp.y
        if (v) tp.x = tp.x.coerceIn(0, maxOf(0, screenW() - tp.width))
        runCatching { wm.removeView(from) }
        expanded = v
        wm.addView(to, tp)
    }

    private fun applyAlpha() {
        bubble.alpha = alphas[alphaIdx]
        panel.alpha = alphas[alphaIdx]
    }

    private fun drag(handle: View, target: View, p: WindowManager.LayoutParams, onTap: (() -> Unit)?) {
        var startX = 0
        var startY = 0
        var downX = 0f
        var downY = 0f
        var moved = false
        val slop = ViewConfiguration.get(ctx).scaledTouchSlop
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = p.x; startY = p.y
                    downX = e.rawX; downY = e.rawY
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt()
                    val dy = (e.rawY - downY).toInt()
                    if (abs(dx) > slop || abs(dy) > slop) moved = true
                    if (moved) {
                        val w = if (target.width > 0) target.width else p.width
                        val h = if (target.height > 0) target.height else ctx.dp(44)
                        p.x = (startX + dx).coerceIn(0, maxOf(0, screenW() - w))
                        p.y = (startY + dy).coerceIn(0, maxOf(0, screenH() - h))
                        runCatching { wm.updateViewLayout(target, p) }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) onTap?.invoke() else {
                        store.posX = p.x
                        store.posY = p.y
                    }
                    true
                }
                else -> false
            }
        }
    }

    // ---------- views ----------

    private fun buildBubble(): View {
        val b = TextView(ctx).apply {
            text = "P"
            textSize = 20f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setTextColor(Palette.PURPLE_LIGHT)
            background = rounded(Palette.BG, ctx.dp(22).toFloat(), Palette.PURPLE, ctx.dp(2))
        }
        drag(b, b, bubbleP) { setExpanded(true) }
        return b
    }

    private fun buildPanel(): View {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Palette.BG, ctx.dp(14).toFloat(), Palette.PURPLE, ctx.dp(1))
            setPadding(ctx.dp(8), ctx.dp(6), ctx.dp(8), ctx.dp(6))
        }

        // header (drag handle)
        val header = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val titles = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        titles.addView(ctx.label("PHANTOM", 14f, Palette.PURPLE_LIGHT, true).apply { letterSpacing = 0.15f })
        titles.addView(ctx.label("RECOIL ASSISTANT", 8f, Palette.MUTED))
        header.addView(titles, lp(0, WRAP, 1f))
        header.addView(ctx.chip("\u25D0", false, 13f) {
            alphaIdx = (alphaIdx + 1) % alphas.size
            store.alphaIdx = alphaIdx
            applyAlpha()
        }, lp(WRAP, WRAP).apply { marginEnd = ctx.dp(4) })
        header.addView(ctx.chip("\u2013", false, 13f) { setExpanded(false) }, lp(WRAP, WRAP).apply { marginEnd = ctx.dp(4) })
        header.addView(ctx.chip("\u2715", false, 13f) { onClose() }, lp(WRAP, WRAP))
        drag(header, root, panelP, null)
        root.addView(header, lp(MATCH, WRAP))

        tabRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        root.addView(tabRow, lp(MATCH, WRAP).apply { topMargin = ctx.dp(6); bottomMargin = ctx.dp(6) })

        scroll = ScrollView(ctx).apply { overScrollMode = View.OVER_SCROLL_NEVER }
        content = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content, MATCH, WRAP)
        root.addView(scroll, lp(MATCH, scrollHeight()))

        root.addView(
            ctx.label("Guidance only - you control the recoil.", 8f, Palette.MUTED).apply { gravity = Gravity.CENTER },
            lp(MATCH, WRAP).apply { topMargin = ctx.dp(4) }
        )
        return root
    }

    // ---------- rendering ----------

    private fun weapon(): Weapon = Weapons.all[weaponIdx]

    private fun render() {
        tabRow.removeAllViews()
        tabNames.forEachIndexed { i, n ->
            tabRow.addView(ctx.chip(n, i == tab, 11f) { tab = i; render() },
                lp(0, WRAP, 1f).apply { marginEnd = if (i < tabNames.lastIndex) ctx.dp(4) else 0 })
        }
        content.removeAllViews()
        when (tab) {
            0 -> renderWeapon()
            1 -> renderSens()
            2 -> renderGyro()
            else -> renderDrills()
        }
        scroll.scrollTo(0, 0)
    }

    private fun row() = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun card(title: String, body: String) {
        val c = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Palette.SURFACE, ctx.dp(10).toFloat())
            setPadding(ctx.dp(10), ctx.dp(8), ctx.dp(10), ctx.dp(8))
        }
        c.addView(ctx.label(title, 12f, Palette.PURPLE_LIGHT, true))
        c.addView(ctx.label(body, 11.5f, Palette.TEXT).apply { setLineSpacing(0f, 1.1f) })
        content.addView(c, lp(MATCH, WRAP).apply { bottomMargin = ctx.dp(6) })
    }

    private fun renderWeapon() {
        val n = Weapons.all.size
        val w = weapon()
        val nav = row()
        nav.addView(ctx.chip("\u25C0", false, 13f) {
            weaponIdx = (weaponIdx - 1 + n) % n; store.weaponIdx = weaponIdx; render()
        })
        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        mid.addView(ctx.label(w.name, 15f, Palette.TEXT, true).apply { gravity = Gravity.CENTER })
        mid.addView(ctx.label(w.category.label, 10f, Palette.MUTED).apply { gravity = Gravity.CENTER })
        nav.addView(mid, lp(0, WRAP, 1f))
        nav.addView(ctx.chip("\u25B6", false, 13f) {
            weaponIdx = (weaponIdx + 1) % n; store.weaponIdx = weaponIdx; render()
        })
        content.addView(nav, lp(MATCH, WRAP).apply { bottomMargin = ctx.dp(6) })

        card("${w.name} note", w.note)
        card("${w.category.label} recoil tips", w.category.tips.joinToString("\n") { "\u2022 $it" })
        card("Reminder", "These are general guidelines. Practice in the training range and adjust to your own hands.")
    }

    private fun save(cur: SensProfile) {
        store.setCustom(weapon().name, style, cur)
        render()
    }

    private fun stepper(name: String, value: Int, rec: Int, onDelta: (Int) -> Unit) {
        val r = row().apply {
            background = rounded(Palette.SURFACE, ctx.dp(10).toFloat())
            setPadding(ctx.dp(10), ctx.dp(6), ctx.dp(6), ctx.dp(6))
        }
        val left = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        left.addView(ctx.label(name, 12f, Palette.TEXT, true))
        left.addView(ctx.label("start: $rec", 9f, Palette.MUTED))
        r.addView(left, lp(0, WRAP, 1f))
        r.addView(ctx.chip("\u2212", false, 14f) { onDelta(-5) })
        r.addView(ctx.label("$value", 14f, Palette.PURPLE_LIGHT, true).apply {
            gravity = Gravity.CENTER
        }, lp(ctx.dp(42), WRAP))
        r.addView(ctx.chip("+", false, 14f) { onDelta(5) })
        content.addView(r, lp(MATCH, WRAP).apply { bottomMargin = ctx.dp(5) })
    }

    private fun renderSens() {
        val w = weapon()
        val rec = Recommender.recommend(w, style)
        val cur = store.getCustom(w.name, style) ?: rec

        val styles = row()
        PlayStyle.values().forEachIndexed { i, s ->
            styles.addView(ctx.chip(s.label, s == style, 11f) {
                style = s; store.styleOrd = s.ordinal; render()
            }, lp(0, WRAP, 1f).apply { marginEnd = if (i < 2) ctx.dp(4) else 0 })
        }
        content.addView(styles, lp(MATCH, WRAP))
        content.addView(
            ctx.label("${w.name} \u2022 ${style.blurb}", 10.5f, Palette.MUTED),
            lp(WRAP, WRAP).apply { topMargin = ctx.dp(4); bottomMargin = ctx.dp(5) }
        )

        stepper("Camera", cur.camera, rec.camera) { d -> save(cur.copy(camera = (cur.camera + d).coerceIn(1, 300))) }
        stepper("ADS (red dot)", cur.ads, rec.ads) { d -> save(cur.copy(ads = (cur.ads + d).coerceIn(1, 300))) }
        stepper("Gyro ADS", cur.gyro, rec.gyro) { d -> save(cur.copy(gyro = (cur.gyro + d).coerceIn(1, 300))) }

        val hasCustom = store.getCustom(w.name, style) != null
        content.addView(
            ctx.chip(if (hasCustom) "Reset to starting values" else "Using starting values", false, 10.5f) {
                if (hasCustom) { store.clearCustom(w.name, style); render() }
            },
            lp(MATCH, WRAP).apply { bottomMargin = ctx.dp(6) }
        )

        val table = StringBuilder()
        Recommender.scopes.forEach { s ->
            table.append("${s.name}: ${Recommender.scopeValue(cur.ads, s)}\n")
        }
        card("ADS helper (from your ADS value)", table.toString().trimEnd())
        card(
            "How to use",
            "Match these numbers in the game's settings by hand. Change one value at a time (about 5), " +
                "test in training, and keep what feels steady. Slider ranges may differ by game version."
        )
    }

    private fun renderGyro() {
        card("1. Find it", "In the game: Settings \u2192 Controls / Sensitivity \u2192 Gyroscope. Option names can vary by version.")
        card("2. Start with ADS-only", "Use gyro only while aiming down sights first. Your thumb keeps handling normal camera movement.")
        card("3. Use it for recoil", "During a burst, a tiny forward tilt of the phone offsets the climb while your thumb tracks the target.")
        card("4. Tune slowly", "Change gyro sensitivity by 5-10. Overshooting = too high. Needing big wrist motion = too low.")
        card("5. Stay steady", "Rest elbows on knees or a table, hold the phone neutral, and re-center between fights.")
    }

    private fun renderDrills() {
        card("Warm-up (2 min)", "Training range: fire bursts at a wall target and pull smoothly straight down. Watch where the marks land.")
        card("Pattern drill", "Pick one weapon. Empty 3 magazines, noting how it climbs and drifts. Repeat with the same pull each time.")
        card("Distance bursts", "At near, mid and far targets, fire 5-round bursts. Adjust burst length to what stays on target.")
        card("Tracking", "Follow a moving bot while strafing. Use small, smooth thumb (or gyro) motions.")
        card("Review", "Change only ONE setting per session, then compare. Take breaks to avoid hand fatigue.")
    }
}
