package com.phantom.recoilassistant.data

/** Weapon families. Modifiers nudge the starting sensitivity for that family. */
enum class Category(
    val label: String,
    val camMod: Int,
    val adsMod: Int,
    val gyroMod: Int,
    val tips: List<String>
) {
    AR(
        "Assault Rifle", 0, 0, 0,
        listOf(
            "Start pulling down the instant you fire - don't wait for the kick.",
            "Past mid range, fire 5-8 round bursts, then re-center your aim.",
            "Aim at upper chest so the natural climb lands near head height."
        )
    ),
    SMG(
        "SMG", 10, 10, 10,
        listOf(
            "Win with movement: strafe and track instead of over-pulling.",
            "Spray widens with distance - keep bursts short beyond close range.",
            "Smooth, small thumb motions beat big corrections."
        )
    ),
    LMG(
        "LMG", -10, -10, -10,
        listOf(
            "Slow to aim: pre-aim corners and angles before you peek.",
            "Use a longer, steady downward pull and commit to the burst.",
            "Reset between bursts; very long sprays drift."
        )
    ),
    SNIPER(
        "Sniper", -15, -25, -30,
        listOf(
            "Recoil resets each shot - re-center on the target before the next.",
            "Lower ADS sensitivity gives finer scoped precision.",
            "Practice scope-in timing in the training range."
        )
    ),
    SHOTGUN(
        "Shotgun", 10, 5, 5,
        listOf(
            "Close the distance with strafing, then fire at point-blank.",
            "Pre-aim at head height around corners.",
            "Spread matters more than recoil - range is your main skill."
        )
    ),
    MARKSMAN(
        "Marksman", -10, -15, -15,
        listOf(
            "Pace your shots - let the reticle settle before the next.",
            "Use a light, quick tap-down after each shot, not a hold.",
            "Lower ADS sensitivity helps with mid/long precision."
        )
    )
}

data class Weapon(val name: String, val category: Category, val note: String)

object Weapons {
    val all: List<Weapon> = listOf(
        Weapon("AK-47", Category.AR, "Hits hard with a noticeable climb. Keep a firm, steady pull-down and burst at range."),
        Weapon("M4", Category.AR, "Forgiving and consistent - a good weapon to learn pull-down timing on."),
        Weapon("ASM10", Category.AR, "Punchy per-shot recoil. Short bursts and quick resets keep it tidy."),
        Weapon("Krig 6", Category.AR, "Mostly vertical climb - a steady downward pull does most of the work."),
        Weapon("BK57", Category.AR, "Heavy vertical kick. Bursts and a confident pull-down are key."),
        Weapon("AK117", Category.AR, "Fast, versatile AR. Practice transitioning from spray to bursts by distance."),
        Weapon("QQ9", Category.SMG, "Very fast fire rate at close range. Track and strafe; keep pull gentle."),
        Weapon("CBR4", Category.SMG, "Close-range specialist. Prioritize tracking over long sprays."),
        Weapon("Fennec", Category.SMG, "Extremely fast fire. Short bursts, stay mobile."),
        Weapon("MX9", Category.SMG, "Balanced SMG - good for learning when to burst vs. spray."),
        Weapon("Chicom", Category.SMG, "Quick and light. Keep bursts short and focus on staying on target."),
        Weapon("RPD", Category.LMG, "Large magazine, slow to ADS. Use steady, committed pulls."),
        Weapon("Holger 26", Category.LMG, "Controlled LMG. Pre-aim and use measured bursts."),
        Weapon("Locus", Category.SNIPER, "One-shot rhythm. Re-center and breathe between shots."),
        Weapon("DL Q33", Category.SNIPER, "Practice quick scope-in and a calm, deliberate second shot."),
        Weapon("Kilo Bolt-Action", Category.MARKSMAN, "Deliberate shots. Settle the reticle between each one."),
        Weapon("SKS", Category.MARKSMAN, "Semi-auto rhythm - a light tap-down after each shot."),
        Weapon("Echo", Category.SHOTGUN, "Close-range focus. Win the approach with strafing.")
    )
}
