package com.phantom.recoilassistant.ui

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

object Palette {
    val BG = 0xFF0B0A10.toInt()
    val SURFACE = 0xFF16131F.toInt()
    val SURFACE2 = 0xFF221C33.toInt()
    val PURPLE = 0xFF8B5CF6.toInt()
    val PURPLE_DARK = 0xFF5B21B6.toInt()
    val PURPLE_LIGHT = 0xFFA78BFA.toInt()
    val TEXT = 0xFFEDE9FE.toInt()
    val MUTED = 0xFF9A93B5.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

fun rounded(color: Int, radiusPx: Float, stroke: Int = 0, strokePx: Int = 0) =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx
        if (strokePx > 0) setStroke(strokePx, stroke)
    }

fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)

fun Context.label(text: String, sp: Float = 12f, color: Int = Palette.TEXT, bold: Boolean = false) =
    TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

fun Context.chip(text: String, selected: Boolean, sp: Float = 12f, onClick: () -> Unit) =
    TextView(this).apply {
        this.text = text
        textSize = sp
        gravity = Gravity.CENTER
        setTextColor(if (selected) 0xFFFFFFFF.toInt() else Palette.PURPLE_LIGHT)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(8), dp(5), dp(8), dp(5))
        background = rounded(
            if (selected) Palette.PURPLE_DARK else Palette.SURFACE2,
            dp(8).toFloat(),
            if (selected) Palette.PURPLE else 0x00000000,
            if (selected) dp(1) else 0
        )
        setOnClickListener { onClick() }
    }
