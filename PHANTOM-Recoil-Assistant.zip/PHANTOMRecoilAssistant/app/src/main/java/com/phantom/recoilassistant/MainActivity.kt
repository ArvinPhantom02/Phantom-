package com.phantom.recoilassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.phantom.recoilassistant.overlay.OverlayService
import com.phantom.recoilassistant.ui.Palette
import com.phantom.recoilassistant.ui.chip
import com.phantom.recoilassistant.ui.dp
import com.phantom.recoilassistant.ui.label
import com.phantom.recoilassistant.ui.lp
import com.phantom.recoilassistant.ui.rounded

class MainActivity : Activity() {

    private lateinit var status: TextView
    private val MATCH = LinearLayout.LayoutParams.MATCH_PARENT
    private val WRAP = LinearLayout.LayoutParams.WRAP_CONTENT

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }

        col.addView(label("PHANTOM", 30f, Palette.PURPLE_LIGHT, true).apply { letterSpacing = 0.2f })
        col.addView(label("RECOIL ASSISTANT", 12f, Palette.MUTED).apply { letterSpacing = 0.25f })

        status = label("", 13f, Palette.TEXT)
        col.addView(card(status), lp(MATCH, WRAP).apply { topMargin = dp(20) })

        col.addView(
            button("1. Grant overlay permission", false) { openOverlaySettings() },
            lp(MATCH, WRAP).apply { topMargin = dp(14) }
        )
        col.addView(
            button("2. Start floating assistant", true) { startOverlay() },
            lp(MATCH, WRAP).apply { topMargin = dp(8) }
        )
        col.addView(
            button("Stop floating assistant", false) {
                stopService(Intent(this, OverlayService::class.java)); refresh()
            },
            lp(MATCH, WRAP).apply { topMargin = dp(8) }
        )
        col.addView(
            button("Open Call of Duty: Mobile", false) { launchGame() },
            lp(MATCH, WRAP).apply { topMargin = dp(8) }
        )

        col.addView(
            card(label(
                "How it works\n" +
                    "\u2022 Tap the purple \"P\" bubble to open the panel; \u2013 collapses it.\n" +
                    "\u2022 Drag the bubble or the panel header to move it. \u25D0 changes transparency.\n" +
                    "\u2022 Tabs: Weapon tips \u2022 Sensitivity profiles \u2022 Gyro guide \u2022 Drills.\n" +
                    "\u2022 Copy the suggested numbers into the game's settings yourself.",
                12.5f, Palette.TEXT
            ).apply { setLineSpacing(0f, 1.15f) }),
            lp(MATCH, WRAP).apply { topMargin = dp(16) }
        )

        col.addView(
            card(label(
                "Fair-play notice\n" +
                    "This app is a guidance tool only. It needs no root, never reads or modifies game files, " +
                    "injects nothing, sends no input, and does not reduce recoil for you. " +
                    "Improvement comes from your own practice and settings.",
                12f, Palette.MUTED
            ).apply { setLineSpacing(0f, 1.15f) }),
            lp(MATCH, WRAP).apply { topMargin = dp(12) }
        )

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Palette.BG)
            addView(col)
        })
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val perm = Settings.canDrawOverlays(this)
        status.text = "Overlay permission: " + (if (perm) "granted \u2713" else "not granted") +
            "\nAssistant: " + (if (OverlayService.running) "running" else "stopped")
    }

    private fun card(child: TextView): LinearLayout = LinearLayout(this).apply {
        background = rounded(Palette.SURFACE, dp(14).toFloat(), Palette.PURPLE_DARK, dp(1))
        setPadding(dp(14), dp(12), dp(14), dp(12))
        addView(child)
    }

    private fun button(text: String, primary: Boolean, onClick: () -> Unit): TextView =
        chip(text, primary, 14f, onClick).apply {
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(13), dp(12), dp(13))
        }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Grant overlay permission first", Toast.LENGTH_SHORT).show()
            openOverlaySettings()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Look for the purple P bubble", Toast.LENGTH_SHORT).show()
        status.postDelayed({ refresh() }, 400)
    }

    private fun launchGame() {
        val pkgs = listOf("com.activision.callofduty.shooter", "com.garena.game.codm")
        val intent = pkgs.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (intent != null) startActivity(intent)
        else Toast.makeText(this, "Call of Duty: Mobile not found", Toast.LENGTH_SHORT).show()
    }
}
