package com.phantom.recoilassistant.data

import android.content.Context

/** Three values the player tunes by hand in the game's settings. */
data class SensProfile(val camera: Int, val ads: Int, val gyro: Int)

enum class PlayStyle(
    val label: String,
    val blurb: String,
    val camera: Int,
    val ads: Int,
    val gyro: Int
) {
    RUSHER("Rusher", "Fast turns, close fights", 120, 110, 160),
    BALANCED("Balanced", "All-round starting point", 100, 95, 140),
    ANCHOR("Anchor", "Slower, precise, longer range", 80, 80, 115)
}

/** ADS multipliers per scope: higher zoom -> lower sensitivity. Starting points only. */
data class ScopeRule(val name: String, val multiplier: Double)

object Recommender {
    val scopes = listOf(
        ScopeRule("Iron / Red dot", 1.00),
        ScopeRule("Holo / 2x", 0.85),
        ScopeRule("3x / 4x", 0.70),
        ScopeRule("6x", 0.55),
        ScopeRule("8x+ / Sniper", 0.45)
    )

    fun recommend(w: Weapon, s: PlayStyle) = SensProfile(
        snap(s.camera + w.category.camMod),
        snap(s.ads + w.category.adsMod),
        snap(s.gyro + w.category.gyroMod)
    )

    fun scopeValue(ads: Int, rule: ScopeRule): Int = Math.round(ads * rule.multiplier).toInt().coerceIn(1, 300)

    private fun snap(v: Int) = (((v + 2) / 5) * 5).coerceIn(5, 300)
}

/** Tiny SharedPreferences wrapper: custom profiles per weapon + play style, and overlay state. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("phantom_prefs", Context.MODE_PRIVATE)

    var weaponIdx: Int
        get() = p.getInt("weapon", 0)
        set(v) = p.edit().putInt("weapon", v).apply()

    var styleOrd: Int
        get() = p.getInt("style", PlayStyle.BALANCED.ordinal)
        set(v) = p.edit().putInt("style", v).apply()

    var alphaIdx: Int
        get() = p.getInt("alpha", 0)
        set(v) = p.edit().putInt("alpha", v).apply()

    var posX: Int
        get() = p.getInt("x", 24)
        set(v) = p.edit().putInt("x", v).apply()

    var posY: Int
        get() = p.getInt("y", 120)
        set(v) = p.edit().putInt("y", v).apply()

    private fun key(weapon: String, style: PlayStyle) = "custom_${weapon}_${style.name}"

    fun getCustom(weapon: String, style: PlayStyle): SensProfile? {
        val parts = p.getString(key(weapon, style), null)?.split(",") ?: return null
        if (parts.size != 3) return null
        val n = parts.mapNotNull { it.toIntOrNull() }
        return if (n.size == 3) SensProfile(n[0], n[1], n[2]) else null
    }

    fun setCustom(weapon: String, style: PlayStyle, s: SensProfile) {
        p.edit().putString(key(weapon, style), "${s.camera},${s.ads},${s.gyro}").apply()
    }

    fun clearCustom(weapon: String, style: PlayStyle) {
        p.edit().remove(key(weapon, style)).apply()
    }
}
