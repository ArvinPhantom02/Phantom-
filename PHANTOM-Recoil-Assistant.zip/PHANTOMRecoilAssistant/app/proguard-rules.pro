# No special rules needed. The app uses only the Android framework.
