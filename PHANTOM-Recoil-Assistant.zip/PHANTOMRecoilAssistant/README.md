# PHANTOM Recoil Assistant
Floating guidance overlay for Call of Duty: Mobile (Kotlin, no dependencies).
Guidance only: no root, no game-file access, no injection, no input automation, no anti-cheat bypass.

Build: open this folder in Android Studio -> wait for Gradle sync -> Build > Build APK(s).
